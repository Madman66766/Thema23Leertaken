/**
 * Created by Christopher on 20/02/2016.
 */
public class Node {
    Node left;
    Node right;
    int data;
    boolean secondPop;

    Node(int data) {
        left = null;
        right = null;
        this.data = data;
    }

}
