/**
 * Created by Christopher on 08/03/2016.
 */
public class Main {
    public static void main(String args[]) {
        Problem problem = new Problem();
        problem.solve();
    }
}
